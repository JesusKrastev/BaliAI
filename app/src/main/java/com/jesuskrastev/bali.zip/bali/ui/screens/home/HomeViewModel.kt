﻿package com.jesuskrastev.bali.ui.screens.home

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jesuskrastev.bali.R
import com.jesuskrastev.bali.data.analytics.AnalyticsTracker
import com.jesuskrastev.bali.domain.repository.AnswerRepository
import com.jesuskrastev.bali.domain.repository.TestResultRepository
import com.jesuskrastev.bali.domain.repository.UserRepository
import com.jesuskrastev.bali.domain.model.Answer
import com.jesuskrastev.bali.domain.model.TestResult
import com.jesuskrastev.bali.domain.model.User
import com.jesuskrastev.bali.domain.util.DateTimeHelper
import com.jesuskrastev.bali.domain.repository.AuthRepository
import com.jesuskrastev.bali.domain.repository.PathRepository
import com.jesuskrastev.bali.domain.usecase.DecrementCoinsUseCase
import com.jesuskrastev.bali.domain.usecase.RestoreEnergyUseCase
import com.jesuskrastev.bali.domain.usecase.GenerateInitialPathUseCase
import com.jesuskrastev.bali.domain.usecase.GenerateNextPathNodesUseCase
import com.jesuskrastev.bali.domain.model.LessonNode
import com.jesuskrastev.bali.ui.util.StreakUiHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val testResultRepository: TestResultRepository,
    private val answerRepository: AnswerRepository,
    private val decrementCoinsUseCase: DecrementCoinsUseCase,
    private val authRepository: AuthRepository,
    private val pathRepository: PathRepository,
    private val generateNextPathNodesUseCase: GenerateNextPathNodesUseCase,
    private val generateInitialPathUseCase: GenerateInitialPathUseCase,
    private val analyticsTracker: AnalyticsTracker,
    private val dateTimeHelper: DateTimeHelper,
    private val restoreEnergyUseCase: RestoreEnergyUseCase,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _isPathLoading = MutableStateFlow(false)
    private val _pathError = MutableStateFlow<String?>(null)

    private val _showEnergyDialog = MutableStateFlow(false)
    private val _showNoCoinsDialog = MutableStateFlow(false)
    private val _dailyTip = MutableStateFlow("")

    private val _pathNodes: StateFlow<List<LessonNode>?> = authRepository.currentUserFlow
        .flatMapLatest { userId -> 
             pathRepository.getPathNodes(userId ?: "") 
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        loadDailyTip()
        observeAndAutoGeneratePath()
        refreshUserState()
    }

    private fun observeAndAutoGeneratePath() {
        viewModelScope.launch {
            _pathNodes
                .filterNotNull()
                .distinctUntilChanged { old, new -> old.isNotEmpty() == new.isNotEmpty() }
                .collect { nodes ->
                    if (nodes.isEmpty() && !_isPathLoading.value) {
                        generateInitialPath()
                    }
                }
        }
    }

    private fun generateInitialPath() {
        viewModelScope.launch {
            _isPathLoading.value = true
            _pathError.value = null
            try {
                generateInitialPathUseCase()
            } catch (e: Exception) {
                _pathError.value = e.localizedMessage
            } finally {
                _isPathLoading.value = false
            }
        }
    }

    private fun loadDailyTip() {
        try {
            val jsonString = context.resources.openRawResource(R.raw.tips).bufferedReader().use { it.readText() }
            val tips = Json.decodeFromString<List<String>>(jsonString)
            if (tips.isNotEmpty()) {
                _dailyTip.value = tips.random()
            }
        } catch (e: Exception) {
            _dailyTip.value = "Conduce con precauciÃ³n y respeta las seÃ±ales."
        }
    }

    private fun refreshUserState() {
        viewModelScope.launch {
            // Espera a que haya un estado de login definido antes de ejecutar
            authRepository.isLoggedIn.first()

            try {
                restoreEnergyUseCase()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        userRepository.get(),
        testResultRepository.count(),
        answerRepository.getRecentMistakes(),
        testResultRepository.getAverageScore(),
        _showEnergyDialog,
        _showNoCoinsDialog,
        _dailyTip,
        authRepository.isLoggedIn,
        _pathNodes,
        _isPathLoading,
        _pathError
    ) { flows ->
        val user = flows[0] as User?
        val totalTests = flows[1] as Int
        val mistakes = flows[2] as List<*>
        val avgScore = flows[3] as Double? ?: 0.0
        val showEnergyDialog = flows[4] as Boolean
        val showNoCoinsDialog = flows[5] as Boolean
        val dailyTip = flows[6] as String
        val isLoggedIn = flows[7] as Boolean
        val pathNodes = flows[8] as List<*>?
        val isPathLoading = flows[9] as Boolean
        val pathError = flows[10] as String?

        @Suppress("UNCHECKED_CAST")
        val typedMistakes = mistakes as List<Answer>
        
        @Suppress("UNCHECKED_CAST")
        val typedPathNodes = (pathNodes ?: emptyList<LessonNode>()) as List<LessonNode>

        val profilePictureUrl = authRepository.currentUserPhotoUrl()
        val userEmail = authRepository.currentUserEmail()

        if (user == null) {
            HomeUiState(
                dailyTip = dailyTip, 
                isLoggedIn = isLoggedIn,
                profilePictureUrl = profilePictureUrl,
                userEmail = userEmail
            )
        } else {
            HomeUiState(
                userName = user.name ?: "Futuro Conductor",
                profilePictureUrl = profilePictureUrl,
                userEmail = userEmail,
                streak = user.currentStreak,
                weekSessions = user.weekSessions,
                weeklyGoal = user.weeklyGoal,
                weekProgressPercent = ((user.weekSessions.toFloat() / user.weeklyGoal.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100),
                avgScore = avgScore.toInt(),
                totalTests = totalTests,
                practiceDays = user.practiceDays,
                xpLevel = user.level,
                energyCount = user.energy,
                lastEnergyUpdateTimestamp = user.lastEnergyUpdateTimestamp,
                mistakesCount = typedMistakes.size,
                coinsCount = user.coins,
                streakFreezes = user.streakFreezes,
                highestStreak = user.highestStreak,
                showEnergyDialog = showEnergyDialog,
                showNoCoinsDialog = showNoCoinsDialog,
                dailyTip = dailyTip,
                isLoggedIn = isLoggedIn,
                weeklyStreak = StreakUiHelper.generateWeeklyStreak(user.practiceDays),
                lastPracticeTimestamp = user.lastPracticeTimestamp,
                pathNodes = typedPathNodes,
                isPathLoading = isPathLoading,
                pathError = pathError
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun signOut(context: Context) {
        viewModelScope.launch {
            authRepository.signOut(context)
            analyticsTracker.logout()
            analyticsTracker.resetUser()
        }
    }

    fun startExam(onSuccess: () -> Unit) {
        viewModelScope.launch {
            val success = decrementCoinsUseCase(100)
            if (success) {
                analyticsTracker.coinsSpent(100, "dgt_simulacro")
                analyticsTracker.dgtSimulacroUnlocked()
                onSuccess()
            } else {
                _showNoCoinsDialog.value = true
            }
        }
    }

    fun showEnergyDialog() {
        _showEnergyDialog.value = true
    }

    fun dismissEnergyDialog() {
        _showEnergyDialog.value = false
    }

    fun dismissNoCoinsDialog() {
        _showNoCoinsDialog.value = false
    }

    fun generateNextPathNodesCount(count: Int = 5) {
        if (_isPathLoading.value) return
        viewModelScope.launch {
            _isPathLoading.value = true
            _pathError.value = null
            try {
                generateNextPathNodesUseCase(count)
            } catch (e: Exception) {
                _pathError.value = e.localizedMessage
            } finally {
                _isPathLoading.value = false
            }
        }
    }
}
